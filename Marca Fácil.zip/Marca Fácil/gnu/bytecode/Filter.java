package gnu.bytecode;

public interface Filter {
    boolean select(Object obj);
}
