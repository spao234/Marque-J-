package gnu.bytecode;

public interface AttrContainer {
    Attribute getAttributes();

    void setAttributes(Attribute attribute);
}
