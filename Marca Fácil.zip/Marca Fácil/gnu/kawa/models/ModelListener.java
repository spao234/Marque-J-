package gnu.kawa.models;

public interface ModelListener {
    void modelUpdated(Model model, Object obj);
}
