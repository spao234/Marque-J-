package com.google.appinventor.components.runtime.util;

public interface OnInitializeListener {
    void onInitialize();
}
