package com.google.appinventor.components.common;

interface package-info {
}
